package rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelDatabaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
