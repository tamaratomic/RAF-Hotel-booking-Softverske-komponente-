package enums;

public class UserTypes {

    public static final String ADMINISTRATOR = "ADMINISTRATOR";
    public static final String STANDARD = "STANDARD";
    public static final String MANAGER = "MANAGER";

}
